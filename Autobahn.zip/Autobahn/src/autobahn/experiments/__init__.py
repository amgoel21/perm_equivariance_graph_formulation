"""Runs code for experiments"""
